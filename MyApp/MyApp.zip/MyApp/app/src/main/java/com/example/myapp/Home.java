package com.example.myapp;

import android.content.Intent;
import android.graphics.RectF;
import android.nfc.Tag;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.samples.vision.ocrreader.OcrGraphic;
import com.google.android.gms.samples.vision.ocrreader.R;
import com.google.android.gms.vision.text.TextBlock;

import java.util.Locale;


public class Home extends AppCompatActivity {
    //private TextView resultTEXT;
    TextView txtview;
    TextView ocrr;
    TextView emer;
    int result;

    TextToSpeech toSpeech;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);



        txtview = (TextView) findViewById(R.id.txt);
        txtview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String txtt;

                txtt= txtview.getText().toString();

                toSpeech = new TextToSpeech(Home.this, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        if (status == TextToSpeech.SUCCESS) {
                            result = toSpeech.setLanguage(Locale.UK);
                        } else {
                            Toast.makeText(getApplicationContext(), "Feature not supported in your device", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                toSpeech.speak(txtt, TextToSpeech.QUEUE_FLUSH, null);

              /*  protected void onDestroy(){
                    Home.super.onDestroy();
                    if (toSpeech != null) {
                        toSpeech.stop();
                        toSpeech.shutdown();
                    }
                }
*/
              Intent intent=new Intent(Home.this,MainActivity.class);
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Feature not supported in your device", Toast.LENGTH_LONG).show();
            }
        });

        ocrr = (TextView)findViewById(R.id.ocr);
        ocrr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home.this,com.google.android.gms.samples.vision.ocrreader.OcrCaptureActivity.class);
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Feature not supported in your device", Toast.LENGTH_LONG).show();
            }
        });



        emer = (TextView)findViewById(R.id.emergency);
        emer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home.this,com.example.myapp.emergency.class);


                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Feature not supported in your device", Toast.LENGTH_LONG).show();
            }
        });

    };




}
